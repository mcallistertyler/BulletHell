﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Boundary
{
    public float xMin, xMax, zMin, zMax;
}

public class playerBullet : MonoBehaviour {

    public float speed;
    public Boundary boundary;

    public GameObject Shot;
    public Transform BulletSpawn;
    public float fireRate;

    private float nextFire;

    void Update()
    {
        if (Time.time > nextFire)
        {
            nextFire = Time.time + fireRate;
            GameObject obj = BulletPoolTest.Current.GetPooledObject();

            if (obj == null) return;
            obj.transform.position = transform.position;
            obj.transform.rotation = transform.rotation;
            obj.SetActive(true);
            }
    }

    void FixedUpdate()
    {
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");

        var movement = new Vector3(moveHorizontal, 0.0f, moveVertical);
        var rigidBody = GetComponent<Rigidbody>();
        rigidBody.velocity = movement * speed;

        rigidBody.position = new Vector3
            (
               Mathf.Clamp(rigidBody.position.x, boundary.xMin, boundary.xMax), 0.0f,
               Mathf.Clamp(rigidBody.position.z, boundary.zMin, boundary.zMax)
            );
    }
}
